package com.test;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DataFile extends HttpServlet{
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
	  
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	          
	    String n=request.getParameter("userName");  
	    out.print("Welcome "+n);  
	     
	  
	 Map<String, List<String>> map = (Map<String, List<String>>) new TreeMap<String, List<String>>();
     // create list one and store values
     List<String> valSetOne = new ArrayList<String>();
     valSetOne.add("Amit");
     valSetOne.add("52");
     valSetOne.add("Physics");
     valSetOne.add("12000");
     
     // create list two and store values
     List<String> valSetTwo = new ArrayList<String>();
     valSetTwo.add("Ravi");
     valSetTwo.add("21");
     valSetTwo.add("Science");
     valSetTwo.add("13000");
     
     // create list three and store values
     List<String> valSetThree = new ArrayList<String>();
     valSetThree.add("Ashwani");
     valSetThree.add("21");
     valSetThree.add("Physics");
     valSetThree.add("13000");
     
     List<String> valSetFour = new ArrayList<String>();
     valSetFour.add("Subhadra");
     valSetFour.add("21");
     valSetFour.add("Physics");
     valSetFour.add("13000");
     
     List<String> valSetFive = new ArrayList<String>();
     valSetFive.add("Bhupendra");
     valSetFive.add("21");
     valSetFive.add("Physics");
     valSetFive.add("13000");
     
     // put values into map
     map.put("1407710001", valSetOne);
     map.put("1407710002", valSetTwo);
     map.put("1407710003", valSetThree);
     map.put("1407710004", valSetFour);
     map.put("1407710005", valSetFive);
     
     request.setAttribute("mp",map);


     RequestDispatcher rd = request.getRequestDispatcher("detail.jsp");
     rd.forward(request, response);
	
   /*  out.println("<html><head><style>"
     		+ "table {\r\n" + 
     		"    border-collapse: collapse;\r\n" + 
     		"    width: 100%;\r\n" + 
     		"}\r\n" + 
     		"\r\n" + 
     		"th, td {\r\n" + 
     		"    text-align: left;\r\n" + 
     		"    padding: 8px;\r\n" + 
     		"}\r\n" + 
     		"\r\n" + 
     		".wrap:nth-child(even) {background-color: #90EE90;}"+
     		".wrap:nth-child(odd) {background-color:#ccccff;}"
     		
     		+ "</style></head><body><table>");
     out.println("<tr>");
     out.println("<th>Emp_Id</th>");
     out.println("<th>Emp_Name</th>");
     out.println("<th>Emp_Age</th>");
     out.println("<th>Emp_Dept</th>");
     out.println("<th>Emp_Salary</th>");
    out.println("</tr>");

     for (Map.Entry<String, List<String>> entry : map.entrySet()) {
         String key = entry.getKey();
         List<String> values = entry.getValue();
         
         out.println("<tr class=\"wrap\">");
         out.println("<td>"+key+"</td>");
         out.println("<td>"+values.get(0)+"</td>");
         out.println("<td>"+values.get(1)+"</td>");
         out.println("<td>"+values.get(2)+"</td>");
         out.println("<td>"+values.get(3)+"</td>");
       
        out.println("</tr>");
     
     
     
     }
	
       out.println("</table></body></html>");
*/
	
	}
}
