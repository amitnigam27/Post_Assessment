function validate(){
	var user=document.getElementById("user");
	var pass=document.getElementById("pass");
	console.log(user + pass);
	var re= /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@*]).{6,}/;
	if(!re.test(pass))
	{
	alert("You should use at least 1 capital letter, 1 small letter, 1 decimal no. and the length should be more than 6 characters...!");
	return false;
	}
	return true;
	
	
	
	
	
}