package com.test;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Check extends HttpServlet{
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {
		
		response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
		
	    String para=request.getParameter("message");
		
		int n= para.length();
		int i;
		char p,a;
		int  counter=1;
		
		char[] ch = para.toCharArray();
		int letter = 0;
		int space = 0;
		int num = 0;
		int other = 0;
		for(i = 0; i <n; i++){
			if(Character.isLetter(ch[i])){
				letter ++ ;
			}
			else if(Character.isDigit(ch[i])){
				num ++ ;
			}
			else if(Character.isSpaceChar(ch[i])){
				space ++ ;
			}
			else{
				other ++;
			}
		}
		out.println(para);
		int total=letter+space+num+other;
		
		for(i=0;i<n;i++)
		{
			a=para.charAt(i);
			if(a==' ') {
				counter++;
			}
		}
		
		
	
	
		List<Integer> list=new ArrayList<Integer>();
		list.add(counter);
		
		list.add(letter);
		list.add(space);
		list.add(num);
		list.add(other);
		list.add(total);
		request.setAttribute("list", list);
		RequestDispatcher rd= request.getRequestDispatcher("display.jsp");
		rd.forward(request, response);

		
		
	}
	

}
